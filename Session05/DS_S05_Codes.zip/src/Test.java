public class Test {
    public static void main(String[] args) {
        int a = 1;
        int b = a++; // b=a; a++
        int c = ++a; // a++; c=a;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);

        int n = 2;
        Integer n2 = null;
    }
}
